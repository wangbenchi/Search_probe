#-*- coding: utf-8 -*-
#### import library
import pygame, sys, random, gc, os, csv, time, psychopy
from psychopy import *
from pygame.locals import *
from math import sin, cos, pi, atan, sqrt, hypot, atan2

#### set constants
white  =(1,1,1) 
black  =(-1,-1,-1)
gray   =(0,0,0)
red    =(1,-1,-1)
green  =(-1,1,-1)

scn_size  = (1440,900)
deg2pix  = int(720/(atan(20.0/63)*180/pi))  ## pixels per visual angle
fix_loc  = (scn_size[0]/2, scn_size[1]/2)
## Orientations for recall
Oris = [10,35,60,85,110,135,160]
## Get the locations of targets
Decc = 2  # the radius of the invisible circle
tar_locs = []
for j in range(6):
    sti_x = int(cos(j*pi/3)*Decc*deg2pix)
    sti_y = int(sin(j*pi/3)*Decc*deg2pix)
    tar_locs.append((sti_x,sti_y))
    
#### define data collect functions
def get_subj_info():
     """ collect participant information"""
     subj   = raw_input("Assign a subject ID(experimenter): ")
     name   = raw_input("Give two random letters to label the subject: ") 
     gender = raw_input("Subject's gender is(f/m): ")
     age    = raw_input("Subject's age is: ")
     dist   = raw_input("dist is(green/red):")
     run    = raw_input("Le/1/2/3/4/5/6/7:")
     return [subj, name, gender, age, dist, run]

def init_data_file(SUBJ_INFO):
    if not os.path.exists('csv_data'): os.mkdir('csv_data')
    file_name = 'csv_data/' + SUBJ_INFO[0] + '_' + SUBJ_INFO[1] + '_' + SUBJ_INFO[4] + '_' + SUBJ_INFO[5] + '.csv'
    data_file = open(file_name, "w")
    header = ['subj', 'name', 'gender', 'age','dist', 'run', 'tar_locs1', 'tar_locs2', 'tar_locs3', 'tar_locs4',
              'tar_locs5', 'tar_locs6', 'shape', 'dist', 'td_dif', 'detection', 'resp_key', 'dis_loc', 'tar_loc',
              'task_type','probe_cond', 'gotKey','startTime','respTime','resp','o1','o2','o3','o4','o5','o6', 'pro_loc', 'ori_resp', 'mode']
    data_file.write('\t'.join(header)+'\n')
    return data_file

#### get the input information, and based on these to set the parameters. 
SUBJ_INFO = get_subj_info() # Get subject info
dist     = SUBJ_INFO[4]
run       = SUBJ_INFO[5]
Subj_num  = int(SUBJ_INFO[0])

#### condition list and trial list
Shape      = ['circle','diamond']
Distractor = [dist,dist,'none']       # whether the Distractor is appear or not. If the distarctor is appear, what color is it, red or green?
TD_dif     = ['same', 'dif']              # target's and distractor's line direction is the same or different
Detection  = ['left','right']             # target's line is on the left or right.
if run <> "Le":
    Task_type  = ['search']*240 + ['probe']*120   # 66.7% trial will be search task in the probe condition
if run == "Le":
    Task_type  = ['search']*360                 # 100% trial will be search task in the learning condition

recall_wd_h_type = ['h_sin']*16 + ['norm','tar']*17   # Find in the distractor condition, which (four) locations you need recall with high likely condition
recall_wd_l_type = ['l_sin']*16 + ['norm','tar']*7   # Find in the distractor condition, which (four) locations you need recall with low likely condition
recall_nd_type   = ['h_norm','l_norm']*13 + ['l_tar']*7    # Find in the no-distractor condition, which (four) locations you need recall; High-tar will be chosen later.
random.shuffle(recall_wd_h_type)
random.shuffle(recall_wd_l_type)
random.shuffle(recall_nd_type)

## The condition list
cond_list  = []
for s in Shape:
    for ds in Distractor:
        for t in TD_dif:
            for d in Detection:
                if d == 'left':
                    resp_key = 'left'
                elif d == 'right':
                    resp_key = 'right'
                cond_list.append([s,ds,t,d,resp_key])

## Define the trial list by adding the target and distractor locations.
trial_list=random.sample(cond_list*5,120)

## Define the fixed distractor (i.e., high likely) location and other locations.
if Subj_num < 7: Fixed_dis = Subj_num-1
if Subj_num > 6 and Subj_num < 13: Fixed_dis = Subj_num - 7
if Subj_num > 12 and Subj_num < 19: Fixed_dis = Subj_num - 13
if Subj_num > 18 and Subj_num < 25: Fixed_dis = Subj_num - 19
Fixed_loc       = tar_locs[Fixed_dis] # High likely location
Other_f_locs    = [l for l in tar_locs if not l in [Fixed_loc]] # Low likely location
Distractor_locs = [Fixed_loc]*50 + Other_f_locs*6 # Here we used a proportion of 62.5% for high likely location

## Almost equal chance for showing target in the without-distractor condition
T_n_locs = [Fixed_loc]*7 + Other_f_locs*6 + random.sample(Other_f_locs,3)
random.shuffle(T_n_locs)
## Get the target location list to make sure the target never appear at the fixed location when the distractor is shown.
T_wf_locs = Other_f_locs*10
random.shuffle(T_wf_locs)

## Add the distractor locations.
j = 0
for i in xrange(120):
    if trial_list[i][1] == 'none':
        trial_list[i] = trial_list[i]+['N_dist']
    else:
        trial_list[i] = trial_list[i]+[Distractor_locs[j]]
        j = j + 1
# Add the target locations.
k = 0
l = 0
for i in range(120):
    if trial_list[i][5] == 'N_dist':
        trial_list[i].append(T_n_locs[k])
        k = k + 1
    elif trial_list[i][5] == Fixed_loc:
        trial_list[i].append(T_wf_locs[l])
        l = l + 1
    elif trial_list[i][5] in Other_f_locs:
        T_wn_loc = random.choice([m for m in Other_f_locs if not m in [trial_list[i][5]]])
        trial_list[i].append(T_wn_loc)
## Add the task_type.
trial_list = trial_list * 3
for i in range(360):
    trial_list[i] = trial_list[i] + [Task_type[i]]
## Add the probe condition.
random.shuffle(trial_list)
m = 0
n = 0
o = 0
for i in range(360):
    if trial_list[i][7] == 'search':
        trial_list[i].append('nr')      # If it is search task, there is no probe.
    elif trial_list[i][7] == 'probe':
        if trial_list[i][5] == 'N_dist':
            if trial_list[i][6] == Fixed_loc:
                trial_list[i].append('h_tar')
            else:
                trial_list[i].append(recall_nd_type[m])
                m = m + 1
        elif trial_list[i][5] <> 'N_dist':
            if trial_list[i][5] == Fixed_loc:
                trial_list[i].append(recall_wd_h_type[n])
                n = n+ 1
            else:
                trial_list[i].append(recall_wd_l_type[o])
                o = o + 1
                
#### Initialize pygame and setup a display
pygame.init()
myWin = visual.Window(size=scn_size, units='pix', fullscr=False, allowGUI=False, color=(-1,-1,-1), winType='pygame')
pygame.mouse.set_visible(False)# do not show the mouse

#### initialize the data files.
DATA_FILE = init_data_file(SUBJ_INFO)

#### define wait function
def wait(DURATION, KEYS_ALLOWED = [], MOUSE_LOC = [],ALLOW_QUIT = True):
    """    John Christie's wait4key() function.
    KEYS_ALLOWED should be a list, like [K_SPACE, K_l]
    ALLOW_QUIT = True, exit when Esc key pressed. """

    # set up a few variables
    timeOut = False; gotKey = False
    startTime = pygame.time.get_ticks()
    pygame.event.clear()

    while not (timeOut or gotKey):
        # check for time out
        current_time = pygame.time.get_ticks()
        if current_time >= (DURATION + startTime):
            timeOut = True
            break
        # check for button press
        for keyp in pygame.event.get():
            if (keyp.type == KEYDOWN):
                # exit pygame if Escape is pressed
                if (keyp.key == K_KP_MULTIPLY) and ALLOW_QUIT :
                    pygame.quit(); sys.exit();
                if keyp.key in KEYS_ALLOWED:
                    gotKey   = True
                    respKey  = pygame.key.name(keyp.key)
                    respTime = current_time
    if gotKey:
        key_resp = [True, startTime, respTime, respKey]
    else:
        key_resp = [False, startTime, None, None]
    return key_resp
        
#### Set constants for the recall wheel 
inner_radius = 4*deg2pix
outer_radius = 4.5*deg2pix
pointer_radius = 5.5*deg2pix

## use four vertices to define a polygon, which will be used as the building block of the recall wheel 
v1 = (cos(-1/180.0*pi)*inner_radius, sin(-1/180.0*pi)*inner_radius)
v2 = (cos(1/180.0*pi)*inner_radius,  sin(1/180.0*pi)*inner_radius)
v3 = (cos(-1/180.0*pi)*outer_radius, sin(-1/180.0*pi)*outer_radius)
v4 = (cos(1/180.0*pi)*outer_radius , sin(1/180.0*pi)*outer_radius)

## vertices to define a triangle-shaped mouse pointer, used to select recall valued from the recall wheel
v5 = (cos(0/180.0*pi)*outer_radius ,   sin(0/180.0*pi)*outer_radius)
v6 = (cos(-1/180.0*pi)*pointer_radius, sin(-1/180.0*pi)*pointer_radius) 
v7 = (cos(1/180.0*pi)*pointer_radius,  sin(1/180.0*pi)*pointer_radius)

## put all stimuli in cache
smpl_item = visual.Rect(win=myWin, width=0.1*deg2pix, height=deg2pix, fillColor=(1,1,1), lineColor=(1,1,1))
square_s  = visual.Rect(win=myWin, width=0.1*deg2pix, height=deg2pix, fillColor=(1,1,1), lineColor=(1,1,1), ori=0) # mark the to-be-recalled item
fix_hor   = visual.Line(win=myWin, start=(-deg2pix/4, 0), end=(deg2pix/4, 0), lineColor=(1,1,1), lineWidth=2)
fix_ver   = visual.Line(win=myWin, start=(0, -deg2pix/4), end=(0, deg2pix/4), lineColor=(1,1,1), lineWidth=2)
text      = visual.TextStim(win=myWin, font="simhei.ttf", height=30)
left_dot  = visual.Line(win=myWin, start=(-int(0.4*deg2pix), 0), end=(-int(0.2*deg2pix), 0), lineColor=(1,1,1), lineWidth=2)
right_dot = visual.Line(win=myWin, start=(int(0.2*deg2pix), 0), end=(int(0.4*deg2pix), 0), lineColor=(1,1,1), lineWidth=2)
sti_cir   = visual.Circle(win=myWin,radius=int(0.7*deg2pix),lineWidth=2)
sti_dia   = visual.Circle(win=myWin,radius=int(0.8*deg2pix),edges=4,lineWidth=2,ori=90)

## building block for orientation wheel (OW)
OW_block  = visual.ShapeStim(win=myWin, vertices=(v1, v2, v4, v3), lineWidth=1.0, fillColor=(0,0,0), lineColor=(0,0,0), size=0.5) 

## pointer to select data from OW
m_pointer = visual.ShapeStim(win=myWin, vertices=(v5,v7,v6),lineWidth=1.0, fillColor=(1,-1,-1), lineColor=(1,-1,-1), size=0.5)

## define a few helpers
def draw_smpl(orientation, position):
    """ function to draw the sample display.
    orientation -- a list that specifies the orientation of each triangle
    position -- a list that specifies the orientation of each triangle.
    """
    #draw the fixation first
    fix_ver.draw();fix_hor.draw()
    # draw all sample display item
    for i in xrange(6):
        smpl_item.setPos(position[i])
        smpl_item.setOri(orientation[i])
        smpl_item.draw()
def draw_OW(OW_center=(0,0)):
    """ function to draw an orientation wheel, centered at OW_center."""
    # make the resolution the same as the color wheel, i.e., 180
    for ori in xrange(180):
        OW_block.setPos(OW_center)
        OW_block.setOri(ori*2)
        OW_block.draw()
def OW_recall(tar_position):
    """ wait until the participant recalls the to-be-remembered item in the sample display.
    tar_position -- position of the to-be-recalled item.
    """
    gotMouse = False
    pygame.mouse.set_pos((scn_size[0]/2+8*deg2pix-tar_position[0],scn_size[1]/2-tar_position[1]))# the initial value of the mouse
    while not gotMouse:
        # check for mouse button press
        for ev in pygame.event.get():           
            if ev.type == MOUSEBUTTONDOWN:
                gotMouse  = True

        # get mouse pointer orientation
        m_x, m_y = pygame.mouse.get_pos()
        tar_x =  scn_size[0]/2 + tar_position[0]; tar_y = scn_size[1]/2 - tar_position[1]
        m_ori = atan2(m_y-tar_y, m_x-tar_x)/(2*pi)*360
        if m_ori < 0: m_ori = 360 + m_ori
        ori_resp = int(m_ori)/2
        m_pointer.setPos((tar_position))
        m_pointer.setFillColor((1,-0.75,-0.75))
        m_pointer.setLineColor((1,-0.75,-0.75))
        m_pointer.setOri(ori_resp*2)

        # put all visual elements on display
        square_s.setPos(tar_position)
        square_s.setOri(ori_resp*2-90)
        square_s.draw()

        draw_OW(tar_position)
        m_pointer.draw()
        myWin.flip()

        ori_resp
    return ori_resp

#### define how to display instruction
def instructions(MODE):
    if MODE == 'prac':
        insImage = visual.ImageStim(win=myWin,image='instructions/probe.png')
        insImage.draw()
    if MODE == 'Sprac':
        insImage = visual.ImageStim(win=myWin,image='instructions/search.png')
        insImage.draw()
    if MODE == 'test':
        text.setText('Press space to continue!')
        text.draw()
    myWin.flip()
    wait(sys.maxint, [K_SPACE], True)

#### error feedback
def error_fdbk(MODE,fix_loc):
    if MODE == 1: text.setText(u'反应错误，请保持注意！') ###feedback when the response is wrong
    if MODE == 2: text.setText(u'看到目标后，请尽快做出反应！') ###feedback when participants do not response
    pygame.mixer.Sound("error.wav").play()
    text.draw()
    myWin.flip()
    wait(1500)
    return True

#### define a function to draw the outlines#########################################################################
def draw_searchpart(fix_loc, shape = '', distr = '', td_dif = '', detect = '', ndnt_locs = [], d_loc = [],t_loc =[]):

    ## draw the fixation first
    fix_ver.draw();fix_hor.draw()
 
    ## draw search outlines
    if dist == 'red':d_c = red;t_c = green
    if dist == 'green': d_c = green;t_c = red

    # Target
    if shape == 'circle':
        sti_cir.setLineColor(t_c)
        sti_cir.setPos(t_loc)
        sti_cir.draw()                    
    if shape == 'diamond':
        sti_dia.setLineColor(t_c)
        sti_dia.setPos(t_loc)
        sti_dia.draw()
    #Distractor
    if shape == 'circle':
        if distr == 'none':
            for i in tar_locs:
                if i <> t_loc:
                    sti_dia.setLineColor(t_c)
                    sti_dia.setPos(i)
                    sti_dia.draw()
        else:
            for i in tar_locs:
                if i <> t_loc:
                    if i == d_loc:
                        sti_dia.setLineColor(d_c)
                    else:
                        sti_dia.setLineColor(t_c)
                    sti_dia.setPos(i)
                    sti_dia.draw()
    if shape == 'diamond':
        if distr == 'none':
            for i in tar_locs:
                if i <> t_loc:
                    sti_cir.setLineColor(t_c)
                    sti_cir.setPos(i)
                    sti_cir.draw()
        else:
            for i in tar_locs:
                if i <> t_loc:
                    if i == d_loc:
                        sti_cir.setLineColor(d_c)
                    else:
                        sti_cir.setLineColor(t_c)
                    sti_cir.setPos(i)
                    sti_cir.draw()

    ## draw inside lines
    # Target
    if detect == 'left': left_dot.setPos(t_loc);left_dot.draw()
    if detect == 'right': right_dot.setPos(t_loc);right_dot.draw()
    # Distractor
    if distr <> 'none':
        if td_dif == 'same':
            if detect == 'left': left_dot.setPos(d_loc);left_dot.draw()
            if detect == 'right': right_dot.setPos(d_loc);right_dot.draw()
            for i in ndnt_locs:
                if ndnt_locs.index(i)==0:
                    if detect == 'left': left_dot.setPos(i);left_dot.draw()
                    if detect == 'right': right_dot.setPos(i);right_dot.draw()
                else:
                    if detect == 'right': left_dot.setPos(i);left_dot.draw()
                    if detect == 'left': right_dot.setPos(i);right_dot.draw()
                        
        if td_dif == 'dif':
            if detect == 'right': left_dot.setPos(d_loc);left_dot.draw()
            if detect == 'left': right_dot.setPos(d_loc);right_dot.draw()
            for i in ndnt_locs:
                if (ndnt_locs.index(i)+1)%2==0: left_dot.setPos(i);left_dot.draw()
                else: right_dot.setPos(i);right_dot.draw()
    else:
        nt_locs = [l for l in tar_locs if not l in [t_loc]]
        for i in nt_locs:
            if (nt_locs.index(i)+1)%2==0:
                if detect == 'left': left_dot.setPos(i);left_dot.draw()
                if detect == 'right': right_dot.setPos(i);right_dot.draw()
            else:
                if detect == 'right': left_dot.setPos(i);left_dot.draw()
                if detect == 'left': right_dot.setPos(i);right_dot.draw()
                        
#### define how to present one trial
def run_trial(fix_loc, trial_par, mode, data_file):
    ## Get the parameters for each trial
    shape, distr, td_dif, detect, response, dis_loc, tar_loc, task_type, pro_cond = trial_par
    TRESP = [None]*4
    SRESP = [None]*4
    smpl_orien = random.sample(Oris, 6)
    oresp = None
    pro_loc = None
    ## Find which exact location to be probed
    ndnt_locs = [l for l in tar_locs if not l in [tar_loc,dis_loc]]
    random.shuffle(ndnt_locs)
    ndnt_loc  = random.choice(ndnt_locs)
    nfnt_locs = [l for l in tar_locs if not l in [tar_loc,Fixed_loc]]
    nfnt_loc  = random.choice(nfnt_locs)
    if pro_cond == 'tar' or pro_cond == 'h_tar' or pro_cond == 'l_tar': pro_loc = tar_loc
    if pro_cond == 'norm': pro_loc = ndnt_loc
    if pro_cond == 'h_norm': pro_loc = Fixed_loc
    if pro_cond == 'l_norm': pro_loc = nfnt_loc
    if pro_cond == 'h_sin' or pro_cond == 'l_sin': pro_loc = dis_loc
    ## Present the fixation for 500 ms
    fix_ver.draw();fix_hor.draw()
    myWin.flip()
    wait(500)
    ## Present the search display
    if task_type == 'probe':
        draw_searchpart(fix_loc, shape, distr, td_dif, detect, ndnt_locs, dis_loc, tar_loc)
        myWin.flip()
        wait(200)
        draw_smpl(smpl_orien, tar_locs)
        myWin.flip()
        wait(100)
        oresp = OW_recall(pro_loc)
    else:
        draw_searchpart(fix_loc, shape, distr, td_dif, detect, ndnt_locs, dis_loc, tar_loc)
        myWin.flip()
        TRESP = wait(3000, [K_LEFT,K_RIGHT], True)
        myWin.flip()
        if TRESP[3] != response and TRESP[3] != None: error_fdbk(1,fix_loc)
        if TRESP[3] == None: error_fdbk(2,fix_loc)
    ## Write data into the data file
    trial_data = SUBJ_INFO + tar_locs + trial_par + TRESP + smpl_orien + [pro_loc,oresp,mode]
    trial_data = map(str, trial_data)   # change all elements to 'string' type
    data_file.write('\t'.join(trial_data) + '\n')

## define experiment###############################################################################
def run_experiment(mode):
    if mode =='practice': l_list = trial_list[0:40]
    if mode =='testing': l_list = trial_list[:]
    random.shuffle(l_list)
    if mode =='testing':
        instructions('test')
    for t in l_list[:]:
        run_trial(fix_loc, t, mode,  DATA_FILE)
        wait(random.randint(500,750))

## start the experiment
if run == 'Le': instructions('Sprac');run_experiment('practice')
if run == '1' or run == '4': instructions('prac');run_experiment('practice')  
run_experiment('testing')

## end experiment
if SUBJ_INFO[5] == '7' or SUBJ_INFO[5] == '3': text.setText("Experiment is over. Thank you for your participation.")
else: text.setText("Please inform the experimentor and have a rest.")
text.draw()
myWin.flip()
wait(3500)

## close data file
DATA_FILE.close()

## close the experiment graphics
pygame.display.quit()
pygame.quit()
